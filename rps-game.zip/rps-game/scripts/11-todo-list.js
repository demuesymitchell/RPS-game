const todoList = [];

function addTodo() {
  const inputElement = document.querySelector('.js-name-input');
  const name = inputElement.value;
  todoList.push(name); // Using the .push to add to the array
  console.log(todoList);

  //Reset the textbox
  inputElement.value = '';
}